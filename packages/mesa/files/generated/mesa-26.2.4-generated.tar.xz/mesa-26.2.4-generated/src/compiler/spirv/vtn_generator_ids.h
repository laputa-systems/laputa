/* DO NOT EDIT - This file is generated automatically by vtn_generator_ids.py script */

/*
 * Copyright (C) 2020 Valve Corporation
 * SPDX-License-Identifier: MIT
 */

enum vtn_generator {
   vtn_generator_llvm_spirv_translator = 6,
   vtn_generator_spirv_tools_assembler = 7,
   vtn_generator_glslang_reference_front_end = 8,
   vtn_generator_shaderc_over_glslang = 13,
   vtn_generator_spiregg = 14,
   vtn_generator_rspirv = 15,
   vtn_generator_mesair_spirv_translator = 16,
   vtn_generator_spirv_tools_linker = 17,
   vtn_generator_vkd3d_shader_compiler = 18,
   vtn_generator_clay_shader_compiler = 19,
   vtn_generator_whlsl_shader_translator = 20,
   vtn_generator_clspv = 21,
   vtn_generator_mlir_spirv_serializer = 22,
   vtn_generator_tint_compiler = 23,
   vtn_generator_angle_shader_compiler = 24,
   vtn_generator_messiah_shader_compiler = 25,
   vtn_generator_xenia_emulator_microcode_translator = 26,
   vtn_generator_rust_gpu_compiler_backend = 27,
   vtn_generator_naga = 28,
   vtn_generator_msp_shader_compiler = 29,
   vtn_generator_spvgentwo_spirv_ir_tools = 30,
   vtn_generator_skia_sksl = 31,
   vtn_generator_beehive_spirv_toolkit = 32,
   vtn_generator_shaderwriter = 33,
   vtn_generator_spirvsmith = 34,
   vtn_generator_shady = 35,
   vtn_generator_taichi = 36,
   vtn_generator_hero_c_compiler = 37,
   vtn_generator_sparksl = 38,
   vtn_generator_nazara_shaderlang_compiler = 39,
   vtn_generator_slang_compiler = 40,
   vtn_generator_zig_compiler = 41,
   vtn_generator_spq = 42,
   vtn_generator_llvm_spirv_backend = 43,
   vtn_generator_kongruent = 44,
   vtn_generator_nuvk_spirv_emitter_and_dlsl_compiler = 45,
   vtn_generator_max = 0xffff,
};
