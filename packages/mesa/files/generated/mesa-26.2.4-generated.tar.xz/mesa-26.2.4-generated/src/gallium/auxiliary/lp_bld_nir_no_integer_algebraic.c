#include "gallivm/lp_bld_nir.h"

#include "nir.h"
#include "nir_builder.h"
#include "nir_search.h"
#include "nir_search_helpers.h"

/* What follows is NIR algebraic transform code for the following 15
 * transforms:
 *    ('fneu', ('seq', 'a@32', 'b@32'), 0.0) => ('feq', 'a', 'b')
 *    ('fneu', ('sne', 'a@32', 'b@32'), 0.0) => ('fneu', 'a', 'b')
 *    ('fneu', ('slt', 'a@32', 'b@32'), 0.0) => ('flt', 'a', 'b')
 *    ('fneu', ('sge', 'a@32', 'b@32'), 0.0) => ('fge', 'a', 'b')
 *    ('fneu', ('bcsel', 'a', 1.0, 0.0), 0.0) => a
 *    ('fneu', ('fcsel', 'a', 1.0, 0.0), 0.0) => ('fneu', 'a', 0.0)
 *    ('fneu', ('fcsel_gt', 'a', 1.0, 0.0), 0.0) => ('flt', 0.0, 'a')
 *    ('fneu', ('fcsel_ge', 'a', 1.0, 0.0), 0.0) => ('fge', 'a', 0.0)
 *    ('seq', 'a@32', 'b@32') => ('bcsel', ('feq', 'a', 'b'), 1.0, 0.0)
 *    ('sne', 'a@32', 'b@32') => ('bcsel', ('fneu', 'a', 'b'), 1.0, 0.0)
 *    ('slt', 'a@32', 'b@32') => ('bcsel', ('flt', 'a', 'b'), 1.0, 0.0)
 *    ('sge', 'a@32', 'b@32') => ('bcsel', ('fge', 'a', 'b'), 1.0, 0.0)
 *    ('fcsel', 'a@32', 'b', 'c') => ('bcsel', ('fneu', 'a', 0.0), 'b', 'c')
 *    ('fcsel_gt', 'a@32', 'b', 'c') => ('bcsel', ('flt', 0.0, 'a'), 'b', 'c')
 *    ('fcsel_ge', 'a@32', 'b', 'c') => ('bcsel', ('fge', 'a', 0.0), 'b', 'c')
 */


static const nir_search_value_union lp_nir_no_integer_lowering_values[] = {
   /* ('fneu', ('seq', 'a@32', 'b@32'), 0.0) => ('feq', 'a', 'b') */
   { .variable = {
      { nir_search_value_variable, 32 },
      0, /* a */
      false,
      -1,
      {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15},
   } },
   { .variable = {
      { nir_search_value_variable, 32 },
      1, /* b */
      false,
      -1,
      {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15},
   } },
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_seq,
      1, 1,
      { 0, 1 },
      -1,
   } },
   { .constant = {
      { nir_search_value_constant, 32 },
      nir_type_float, { 0x0ull /* 0.0 */ },
   } },
   { .expression = {
      { nir_search_value_expression, 1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_fneu,
      0, 2,
      { 2, 3 },
      -1,
   } },

   /* replace0_0 -> 0 in the cache */
   /* replace0_1 -> 1 in the cache */
   { .expression = {
      { nir_search_value_expression, 1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_feq,
      0, 1,
      { 0, 1 },
      -1,
   } },

   /* ('fneu', ('sne', 'a@32', 'b@32'), 0.0) => ('fneu', 'a', 'b') */
   /* search1_0_0 -> 0 in the cache */
   /* search1_0_1 -> 1 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_sne,
      1, 1,
      { 0, 1 },
      -1,
   } },
   /* search1_1 -> 3 in the cache */
   { .expression = {
      { nir_search_value_expression, 1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_fneu,
      0, 2,
      { 6, 3 },
      -1,
   } },

   /* replace1_0 -> 0 in the cache */
   /* replace1_1 -> 1 in the cache */
   { .expression = {
      { nir_search_value_expression, 1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_fneu,
      0, 1,
      { 0, 1 },
      -1,
   } },

   /* ('fneu', ('slt', 'a@32', 'b@32'), 0.0) => ('flt', 'a', 'b') */
   /* search2_0_0 -> 0 in the cache */
   /* search2_0_1 -> 1 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_slt,
      -1, 0,
      { 0, 1 },
      -1,
   } },
   /* search2_1 -> 3 in the cache */
   { .expression = {
      { nir_search_value_expression, 1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_fneu,
      0, 1,
      { 9, 3 },
      -1,
   } },

   /* replace2_0 -> 0 in the cache */
   /* replace2_1 -> 1 in the cache */
   { .expression = {
      { nir_search_value_expression, 1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_flt,
      -1, 0,
      { 0, 1 },
      -1,
   } },

   /* ('fneu', ('sge', 'a@32', 'b@32'), 0.0) => ('fge', 'a', 'b') */
   /* search3_0_0 -> 0 in the cache */
   /* search3_0_1 -> 1 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_sge,
      -1, 0,
      { 0, 1 },
      -1,
   } },
   /* search3_1 -> 3 in the cache */
   { .expression = {
      { nir_search_value_expression, 1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_fneu,
      0, 1,
      { 12, 3 },
      -1,
   } },

   /* replace3_0 -> 0 in the cache */
   /* replace3_1 -> 1 in the cache */
   { .expression = {
      { nir_search_value_expression, 1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_fge,
      -1, 0,
      { 0, 1 },
      -1,
   } },

   /* ('fneu', ('bcsel', 'a', 1.0, 0.0), 0.0) => a */
   { .variable = {
      { nir_search_value_variable, 1 },
      0, /* a */
      false,
      -1,
      {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15},
   } },
   { .constant = {
      { nir_search_value_constant, 0 },
      nir_type_float, { 0x3ff0000000000000ull /* 1.0 */ },
   } },
   { .constant = {
      { nir_search_value_constant, 0 },
      nir_type_float, { 0x0ull /* 0.0 */ },
   } },
   { .expression = {
      { nir_search_value_expression, 0 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel,
      -1, 0,
      { 15, 16, 17 },
      -1,
   } },
   /* search4_1 -> 17 in the cache */
   { .expression = {
      { nir_search_value_expression, 1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_fneu,
      0, 1,
      { 18, 17 },
      -1,
   } },

   /* replace4 -> 15 in the cache */

   /* ('fneu', ('fcsel', 'a', 1.0, 0.0), 0.0) => ('fneu', 'a', 0.0) */
   /* search5_0_0 -> 0 in the cache */
   { .constant = {
      { nir_search_value_constant, 32 },
      nir_type_float, { 0x3ff0000000000000ull /* 1.0 */ },
   } },
   /* search5_0_2 -> 3 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_fcsel,
      -1, 0,
      { 0, 20, 3 },
      -1,
   } },
   /* search5_1 -> 3 in the cache */
   { .expression = {
      { nir_search_value_expression, 1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_fneu,
      0, 1,
      { 21, 3 },
      -1,
   } },

   /* replace5_0 -> 0 in the cache */
   /* replace5_1 -> 3 in the cache */
   { .expression = {
      { nir_search_value_expression, 1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_fneu,
      0, 1,
      { 0, 3 },
      -1,
   } },

   /* ('fneu', ('fcsel_gt', 'a', 1.0, 0.0), 0.0) => ('flt', 0.0, 'a') */
   /* search6_0_0 -> 0 in the cache */
   /* search6_0_1 -> 20 in the cache */
   /* search6_0_2 -> 3 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_fcsel_gt,
      -1, 0,
      { 0, 20, 3 },
      -1,
   } },
   /* search6_1 -> 3 in the cache */
   { .expression = {
      { nir_search_value_expression, 1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_fneu,
      0, 1,
      { 24, 3 },
      -1,
   } },

   /* replace6_0 -> 3 in the cache */
   /* replace6_1 -> 0 in the cache */
   { .expression = {
      { nir_search_value_expression, 1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_flt,
      -1, 0,
      { 3, 0 },
      -1,
   } },

   /* ('fneu', ('fcsel_ge', 'a', 1.0, 0.0), 0.0) => ('fge', 'a', 0.0) */
   /* search7_0_0 -> 0 in the cache */
   /* search7_0_1 -> 20 in the cache */
   /* search7_0_2 -> 3 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_fcsel_ge,
      -1, 0,
      { 0, 20, 3 },
      -1,
   } },
   /* search7_1 -> 3 in the cache */
   { .expression = {
      { nir_search_value_expression, 1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_fneu,
      0, 1,
      { 27, 3 },
      -1,
   } },

   /* replace7_0 -> 0 in the cache */
   /* replace7_1 -> 3 in the cache */
   { .expression = {
      { nir_search_value_expression, 1 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_fge,
      -1, 0,
      { 0, 3 },
      -1,
   } },

   /* ('seq', 'a@32', 'b@32') => ('bcsel', ('feq', 'a', 'b'), 1.0, 0.0) */
   /* search8_0 -> 0 in the cache */
   /* search8_1 -> 1 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_seq,
      0, 1,
      { 0, 1 },
      -1,
   } },

   /* replace8_0_0 -> 0 in the cache */
   /* replace8_0_1 -> 1 in the cache */
   /* replace8_0 -> 5 in the cache */
   /* replace8_1 -> 20 in the cache */
   /* replace8_2 -> 3 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel,
      -1, 1,
      { 5, 20, 3 },
      -1,
   } },

   /* ('sne', 'a@32', 'b@32') => ('bcsel', ('fneu', 'a', 'b'), 1.0, 0.0) */
   /* search9_0 -> 0 in the cache */
   /* search9_1 -> 1 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_sne,
      0, 1,
      { 0, 1 },
      -1,
   } },

   /* replace9_0_0 -> 0 in the cache */
   /* replace9_0_1 -> 1 in the cache */
   /* replace9_0 -> 8 in the cache */
   /* replace9_1 -> 20 in the cache */
   /* replace9_2 -> 3 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel,
      -1, 1,
      { 8, 20, 3 },
      -1,
   } },

   /* ('slt', 'a@32', 'b@32') => ('bcsel', ('flt', 'a', 'b'), 1.0, 0.0) */
   /* search10_0 -> 0 in the cache */
   /* search10_1 -> 1 in the cache */
   /* search10 -> 9 in the cache */

   /* replace10_0_0 -> 0 in the cache */
   /* replace10_0_1 -> 1 in the cache */
   /* replace10_0 -> 11 in the cache */
   /* replace10_1 -> 20 in the cache */
   /* replace10_2 -> 3 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel,
      -1, 0,
      { 11, 20, 3 },
      -1,
   } },

   /* ('sge', 'a@32', 'b@32') => ('bcsel', ('fge', 'a', 'b'), 1.0, 0.0) */
   /* search11_0 -> 0 in the cache */
   /* search11_1 -> 1 in the cache */
   /* search11 -> 12 in the cache */

   /* replace11_0_0 -> 0 in the cache */
   /* replace11_0_1 -> 1 in the cache */
   /* replace11_0 -> 14 in the cache */
   /* replace11_1 -> 20 in the cache */
   /* replace11_2 -> 3 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      true,
      -1,
      nir_op_bcsel,
      -1, 0,
      { 14, 20, 3 },
      -1,
   } },

   /* ('fcsel', 'a@32', 'b', 'c') => ('bcsel', ('fneu', 'a', 0.0), 'b', 'c') */
   /* search12_0 -> 0 in the cache */
   /* search12_1 -> 1 in the cache */
   { .variable = {
      { nir_search_value_variable, 32 },
      2, /* c */
      false,
      -1,
      {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15},
   } },
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_fcsel,
      -1, 0,
      { 0, 1, 36 },
      -1,
   } },

   /* replace12_0_0 -> 0 in the cache */
   /* replace12_0_1 -> 3 in the cache */
   /* replace12_0 -> 23 in the cache */
   /* replace12_1 -> 1 in the cache */
   /* replace12_2 -> 36 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_bcsel,
      -1, 1,
      { 23, 1, 36 },
      -1,
   } },

   /* ('fcsel_gt', 'a@32', 'b', 'c') => ('bcsel', ('flt', 0.0, 'a'), 'b', 'c') */
   /* search13_0 -> 0 in the cache */
   /* search13_1 -> 1 in the cache */
   /* search13_2 -> 36 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_fcsel_gt,
      -1, 0,
      { 0, 1, 36 },
      -1,
   } },

   /* replace13_0_0 -> 3 in the cache */
   /* replace13_0_1 -> 0 in the cache */
   /* replace13_0 -> 26 in the cache */
   /* replace13_1 -> 1 in the cache */
   /* replace13_2 -> 36 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_bcsel,
      -1, 0,
      { 26, 1, 36 },
      -1,
   } },

   /* ('fcsel_ge', 'a@32', 'b', 'c') => ('bcsel', ('fge', 'a', 0.0), 'b', 'c') */
   /* search14_0 -> 0 in the cache */
   /* search14_1 -> 1 in the cache */
   /* search14_2 -> 36 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_fcsel_ge,
      -1, 0,
      { 0, 1, 36 },
      -1,
   } },

   /* replace14_0_0 -> 0 in the cache */
   /* replace14_0_1 -> 3 in the cache */
   /* replace14_0 -> 29 in the cache */
   /* replace14_1 -> 1 in the cache */
   /* replace14_2 -> 36 in the cache */
   { .expression = {
      { nir_search_value_expression, 32 },
      nir_fp_fast_math,
      nir_fp_fast_math,
      false,
      -1,
      nir_op_bcsel,
      -1, 0,
      { 29, 1, 36 },
      -1,
   } },

};



static const struct transform lp_nir_no_integer_lowering_transforms[] = {
   { ~0, ~0, ~0 }, /* Sentinel */

   { 30, 31, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 32, 33, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 9, 34, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 12, 35, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 37, 38, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 37, 38, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 39, 40, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 39, 40, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 41, 42, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 41, 42, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 4, 5, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 7, 8, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 10, 11, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 13, 14, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 19, 15, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 22, 23, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 25, 26, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

   { 28, 29, 0 },
   { ~0, ~0, ~0 }, /* Sentinel */

};

static const struct per_op_table lp_nir_no_integer_lowering_pass_op_table[nir_num_search_ops] = {
   [nir_op_fneu] = {
      .filter = (const uint16_t []) {
         0,
         1,
         2,
         3,
         4,
         5,
         6,
         0,
         7,
         0,
         8,
         0,
         9,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
      },
      
      .num_filtered_states = 10,
      .table = (const uint16_t []) {
      
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         13,
         14,
         15,
         16,
         17,
         18,
         19,
         20,
         0,
         13,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         14,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         15,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         16,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         17,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         18,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         19,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         20,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
      },
   },
   [nir_op_seq] = {
      .filter = NULL,
      
      .num_filtered_states = 1,
      .table = (const uint16_t []) {
      
         2,
      },
   },
   [nir_op_sne] = {
      .filter = NULL,
      
      .num_filtered_states = 1,
      .table = (const uint16_t []) {
      
         3,
      },
   },
   [nir_op_slt] = {
      .filter = NULL,
      
      .num_filtered_states = 1,
      .table = (const uint16_t []) {
      
         4,
      },
   },
   [nir_op_sge] = {
      .filter = NULL,
      
      .num_filtered_states = 1,
      .table = (const uint16_t []) {
      
         5,
      },
   },
   [nir_op_bcsel] = {
      .filter = (const uint16_t []) {
         0,
         1,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
      },
      
      .num_filtered_states = 2,
      .table = (const uint16_t []) {
      
         0,
         0,
         0,
         6,
         0,
         0,
         0,
         6,
      },
   },
   [nir_op_fcsel] = {
      .filter = (const uint16_t []) {
         0,
         1,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
      },
      
      .num_filtered_states = 2,
      .table = (const uint16_t []) {
      
         7,
         7,
         7,
         8,
         7,
         7,
         7,
         8,
      },
   },
   [nir_op_fcsel_gt] = {
      .filter = (const uint16_t []) {
         0,
         1,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
      },
      
      .num_filtered_states = 2,
      .table = (const uint16_t []) {
      
         9,
         9,
         9,
         10,
         9,
         9,
         9,
         10,
      },
   },
   [nir_op_fcsel_ge] = {
      .filter = (const uint16_t []) {
         0,
         1,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
         0,
      },
      
      .num_filtered_states = 2,
      .table = (const uint16_t []) {
      
         11,
         11,
         11,
         12,
         11,
         11,
         11,
         12,
      },
   },
};

/* Mapping from state index to offset in transforms (0 being no transforms) */
static const uint16_t lp_nir_no_integer_lowering_transform_offsets[] = {
   0,
   0,
   1,
   3,
   5,
   7,
   0,
   9,
   11,
   13,
   15,
   17,
   19,
   21,
   23,
   25,
   27,
   29,
   31,
   33,
   35,
};

static const nir_algebraic_table lp_nir_no_integer_lowering_table = {
   .transforms = lp_nir_no_integer_lowering_transforms,
   .transform_offsets = lp_nir_no_integer_lowering_transform_offsets,
   .pass_op_table = lp_nir_no_integer_lowering_pass_op_table,
   .values = lp_nir_no_integer_lowering_values,
   .expression_cond = NULL,
   .variable_cond = NULL,
};

bool
lp_nir_no_integer_lowering(
   nir_shader *shader
) {
   bool progress = false;
   bool condition_flags[1];
   const nir_shader_compiler_options *options = shader->options;
   const shader_info *info = &shader->info;
   (void) options;
   (void) info;

   STATIC_ASSERT(43 == ARRAY_SIZE(lp_nir_no_integer_lowering_values));
   condition_flags[0] = true;

   nir_foreach_function_impl(impl, shader) {
     progress |= nir_algebraic_impl(impl, condition_flags, &lp_nir_no_integer_lowering_table);
   }

   return progress;
}

