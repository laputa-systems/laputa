/* Copyright (C) 2020 Google, Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice (including the next
 * paragraph) shall be included in all copies or substantial portions of the
 * Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS
 * IN THE SOFTWARE.
 */

#include "u_tracepoints.h"


#define __NEEDS_TRACE_PRIV
#include "util/u_debug.h"
#include "util/perf/u_trace_priv.h"


/*
 * surface
 */
  
static void __print_surface(FILE *out, const void *arg, const void *indirect) {
   const struct trace_surface *__entry =
      (const struct trace_surface *)arg;
   fprintf(out, "%u samples, fmt=%s\n"
           , __entry->nr_samples
           , __entry->format
   );
}

  
static void __print_json_surface(FILE *out, const void *arg, const void *indirect) {
   const struct trace_surface *__entry =
      (const struct trace_surface *)arg;
   fprintf(out, "\"unstructured\": \"%u samples, fmt=%s\""
           , __entry->nr_samples
           , __entry->format
   );
}

#define __print_fuzzy_hash_args_surface NULL

static uint32_t __fuzzy_hash_surface(const void *_event) {
   uint32_t hash = 1;
   const struct trace_surface *__entry =
      (const struct trace_surface *)_event;
   (void)__entry;
   return hash;
}

static bool __fuzzy_equals_surface(const void *_a, const void *_b) {
   const struct trace_surface *__entry_a =
      (const struct trace_surface *)_a;
   (void)__entry_a;
   const struct trace_surface *__entry_b =
      (const struct trace_surface *)_b;
   (void)__entry_b;
   return true;
}

static const struct u_tracepoint __tp_surface = {
    "surface",
    ALIGN_POT(sizeof(struct trace_surface), 8),   /* keep size 64b aligned */
    0
    ,
    0,
    0,
    u_tracepoint_type_marker,
    __print_surface,
    __print_json_surface,
    __fuzzy_hash_surface,
    __fuzzy_equals_surface,
    __print_fuzzy_hash_args_surface,
};
void __trace_surface(
     struct u_trace *ut
   , enum u_trace_type enabled_traces
   , void *cs
   , const struct pipe_surface * psurf
) {
   struct trace_surface entry;
   const bool queueing = enabled_traces & U_TRACE_TYPE_REQUIRE_QUEUING;
   UNUSED struct trace_surface *__entry =
      queueing ?
      (struct trace_surface *)u_trace_appendv(ut, cs, &__tp_surface,
                                                    0
                                                    ,
                                                    0, NULL, NULL
                                                    ) :
      &entry;
   __entry->nr_samples = psurf->nr_samples;
   __entry->format = util_format_short_name(psurf->format);
}

/*
 * framebuffer
 */
  
static void __print_framebuffer(FILE *out, const void *arg, const void *indirect) {
   const struct trace_framebuffer *__entry =
      (const struct trace_framebuffer *)arg;
   fprintf(out, "%ux%ux%u@%u, nr_cbufs: %u\n"
           , __entry->width
           , __entry->height
           , __entry->layers
           , __entry->samples
           , __entry->nr_cbufs
   );
}

  
static void __print_json_framebuffer(FILE *out, const void *arg, const void *indirect) {
   const struct trace_framebuffer *__entry =
      (const struct trace_framebuffer *)arg;
   fprintf(out, "\"unstructured\": \"%ux%ux%u@%u, nr_cbufs: %u\""
           , __entry->width
           , __entry->height
           , __entry->layers
           , __entry->samples
           , __entry->nr_cbufs
   );
}

#define __print_fuzzy_hash_args_framebuffer NULL

static uint32_t __fuzzy_hash_framebuffer(const void *_event) {
   uint32_t hash = 1;
   const struct trace_framebuffer *__entry =
      (const struct trace_framebuffer *)_event;
   (void)__entry;
   return hash;
}

static bool __fuzzy_equals_framebuffer(const void *_a, const void *_b) {
   const struct trace_framebuffer *__entry_a =
      (const struct trace_framebuffer *)_a;
   (void)__entry_a;
   const struct trace_framebuffer *__entry_b =
      (const struct trace_framebuffer *)_b;
   (void)__entry_b;
   return true;
}

static const struct u_tracepoint __tp_framebuffer = {
    "framebuffer",
    ALIGN_POT(sizeof(struct trace_framebuffer), 8),   /* keep size 64b aligned */
    0
    ,
    0,
    1,
    u_tracepoint_type_marker,
    __print_framebuffer,
    __print_json_framebuffer,
    __fuzzy_hash_framebuffer,
    __fuzzy_equals_framebuffer,
    __print_fuzzy_hash_args_framebuffer,
};
void __trace_framebuffer(
     struct u_trace *ut
   , enum u_trace_type enabled_traces
   , void *cs
   , const struct pipe_framebuffer_state * pfb
) {
   struct trace_framebuffer entry;
   const bool queueing = enabled_traces & U_TRACE_TYPE_REQUIRE_QUEUING;
   UNUSED struct trace_framebuffer *__entry =
      queueing ?
      (struct trace_framebuffer *)u_trace_appendv(ut, cs, &__tp_framebuffer,
                                                    0
                                                    ,
                                                    0, NULL, NULL
                                                    ) :
      &entry;
   __entry->width = pfb->width;
   __entry->height = pfb->height;
   __entry->layers = pfb->layers;
   __entry->samples = pfb->samples;
   __entry->nr_cbufs = pfb->nr_cbufs;
}

/*
 * grid_info
 */
  
static void __print_grid_info(FILE *out, const void *arg, const void *indirect) {
   const struct trace_grid_info *__entry =
      (const struct trace_grid_info *)arg;
   fprintf(out, "work_dim=%u, block=%ux%ux%u, grid=%ux%ux%u\n"
           , __entry->work_dim
           , __entry->block_x
           , __entry->block_y
           , __entry->block_z
           , __entry->grid_x
           , __entry->grid_y
           , __entry->grid_z
   );
}

  
static void __print_json_grid_info(FILE *out, const void *arg, const void *indirect) {
   const struct trace_grid_info *__entry =
      (const struct trace_grid_info *)arg;
   fprintf(out, "\"unstructured\": \"work_dim=%u, block=%ux%ux%u, grid=%ux%ux%u\""
           , __entry->work_dim
           , __entry->block_x
           , __entry->block_y
           , __entry->block_z
           , __entry->grid_x
           , __entry->grid_y
           , __entry->grid_z
   );
}

#define __print_fuzzy_hash_args_grid_info NULL

static uint32_t __fuzzy_hash_grid_info(const void *_event) {
   uint32_t hash = 1;
   const struct trace_grid_info *__entry =
      (const struct trace_grid_info *)_event;
   (void)__entry;
   return hash;
}

static bool __fuzzy_equals_grid_info(const void *_a, const void *_b) {
   const struct trace_grid_info *__entry_a =
      (const struct trace_grid_info *)_a;
   (void)__entry_a;
   const struct trace_grid_info *__entry_b =
      (const struct trace_grid_info *)_b;
   (void)__entry_b;
   return true;
}

static const struct u_tracepoint __tp_grid_info = {
    "grid_info",
    ALIGN_POT(sizeof(struct trace_grid_info), 8),   /* keep size 64b aligned */
    0
    ,
    0,
    2,
    u_tracepoint_type_marker,
    __print_grid_info,
    __print_json_grid_info,
    __fuzzy_hash_grid_info,
    __fuzzy_equals_grid_info,
    __print_fuzzy_hash_args_grid_info,
};
void __trace_grid_info(
     struct u_trace *ut
   , enum u_trace_type enabled_traces
   , void *cs
   , const struct pipe_grid_info * pgrid
) {
   struct trace_grid_info entry;
   const bool queueing = enabled_traces & U_TRACE_TYPE_REQUIRE_QUEUING;
   UNUSED struct trace_grid_info *__entry =
      queueing ?
      (struct trace_grid_info *)u_trace_appendv(ut, cs, &__tp_grid_info,
                                                    0
                                                    ,
                                                    0, NULL, NULL
                                                    ) :
      &entry;
   __entry->work_dim = pgrid->work_dim;
   __entry->block_x = pgrid->block[0];
   __entry->block_y = pgrid->block[1];
   __entry->block_z = pgrid->block[2];
   __entry->grid_x = pgrid->grid[0];
   __entry->grid_y = pgrid->grid[1];
   __entry->grid_z = pgrid->grid[2];
}

